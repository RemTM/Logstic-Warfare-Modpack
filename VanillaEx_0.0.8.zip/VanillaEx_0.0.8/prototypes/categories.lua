data:extend(
{
  {
    type = "ammo-category",
    name = "tank-flame-thrower"
  },
  {
    type = "ammo-category",
    name = "autocannon-shell"
  },
  {
    type = "ammo-category",
    name = "flakcannon-shell"
  },
  {
    type = "ammo-category",
    name = "arty-shell"
  },
    {
    type = "ammo-category",
    name = "mb-cannon-shell"
  },
}
)
