enable_guns=true -- Enable VanillaEx guns and ammo.

enable_vehicles_civilian=true -- Enables VanillaEx civilian vehicles such as Trucks, Boats, Civilian Planes, etc.
enable_vehicles_military=true -- Enables VanillaEx military vehicles such as Tanks, IFVs, SPAAGs, SPGs, Bombers, etc.

enable_defense=true -- Enable VanillaEx defensive structures (more walls, more turrets).

enable_energy=false -- Enable VanillaEx energy structures.

--enable_planes=false -- WIP