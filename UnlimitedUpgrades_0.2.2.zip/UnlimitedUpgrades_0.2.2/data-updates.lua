--procedural generation of upgrades for unaccounted ammo
--first go over all prototypes and find different ammo types
require "util"
ammotypes={};
for name,prototype in pairs(data.raw.ammo) do
    if prototype.type=='ammo' and data.raw.technology['unl-'..prototype.ammo_type.category..'-damage']==nil then
        ammotypes[prototype.ammo_type.category]='true'
    end
end
--then generate technologies for those
function gentable(arg)
    name=arg.name
    prereqs=arg.prereqs or {'military-4'};
    count=arg.count or 400;
    icon=arg.icon or "unlimited"; icon="__UnlimitedUpgrades__/icons/"..icon..".png";  
return  {
        type = "technology",
        name = 'unl-'..name,
        icon = icon,
        effects ={},
        prerequisites=prereqs,
        unit ={
            count = count,
            ingredients ={
                    {"alien-science-pack", 2},
                    {"science-pack-1", 2},
                    {"science-pack-2", 2},
                    {"science-pack-3", 2}
                },
            time = 60
            },
        upgrade=true,
        order='e-n-z'
        }
end
techs={};
for cat,_ in pairs(ammotypes) do
    teh1=gentable{name=cat..'-damage'}
    teh2=gentable{name=cat..'-speed',count=350}
    table.insert(techs,teh1); table.insert(techs,teh2);
end
data:extend(
    techs
)
table.insert(data.raw.technology["military-3"].effects,{type = "unlock-recipe",recipe = "railgun"})
table.insert(data.raw.technology["military-3"].effects,{type = "unlock-recipe",recipe = "railgun-dart"})
