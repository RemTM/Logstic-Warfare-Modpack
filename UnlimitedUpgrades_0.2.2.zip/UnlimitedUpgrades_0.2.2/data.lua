require "util"
function gentable(arg)
    name=arg.name
    prereqs=arg.prereqs or {'military-4'};
    count=arg.count or 400;
    icon=arg.icon or "unlimited"; icon="__UnlimitedUpgrades__/icons/"..icon..".png";  
return  {
        type = "technology",
        name = 'unl-'..name,
        icon = icon,
        effects ={},
        prerequisites=prereqs,
        unit ={
            count = count,
            ingredients ={
                    {"alien-science-pack", 2},
                    {"science-pack-1", 2},
                    {"science-pack-2", 2},
                    {"science-pack-3", 2}
                },
            time = 60
            },
        upgrade=true,
        order='e-n-z'
        }
end
data:extend({
    --bullet dmg
    gentable{name='bullet-damage',prereqs={'military-4',"bullet-damage-6"}, icon='unlimited-bullet-damage'},
    --bullet speed
    gentable{name='bullet-speed',count=350,prereqs={'military-4',"bullet-speed-6"}, icon='unlimited-bullet-speed'},
    --cannon-shell dmg
    gentable{name='cannon-shell-damage',count=350, prereqs={'military-4',"tanks"}, icon='unlimited-cannon-shell-damage'},
    --cannon-shell speed
    gentable{name='cannon-shell-speed', count=330, prereqs={'military-4',"tanks"}, icon='unlimited-cannon-shell-speed'},
    --flame-thrower dmg
    gentable{name='flame-thrower-damage', count=370, prereqs={'military-4',"flame-thrower"}, icon='unlimited-flame-thrower-damage'},
    --flame thrower speed
    gentable{name='flame-thrower-speed', count=340, prereqs={'military-4',"flame-thrower"}, icon='unlimited-cannon-shell-speed'},
    --railgun dmg --this one is taken care of by data-updates
    --gentable{name='railgun-damage'},
    ----railgun speed
    --gentable{name='railgun-speed', count=350},
    ----rocket dmg
    gentable{name='rocket-damage',prereqs={'military-4',"rocket-damage-5"},icon='unlimited-rocket-damage'},
    --rocket speed
    gentable{name='rocket-speed', count=350, prereqs={'military-4',"rocket-speed-5"},icon='unlimited-rocket-speed'},
    --shotgun-shell dmg
    gentable{name='shotgun-shell-damage',prereqs={'military-4',"shotgun-shell-damage-6"}, icon='unlimited-shotgun-shell-damage'},
    --shotgun speed
    gentable{name='shotgun-shell-speed', count=350, prereqs={'military-4',"shotgun-shell-speed-6"}, icon='unlimited-shotgun-shell-speed'},
    --gun-turret damage
    gentable{name='gun-turret-damage',prereqs={'military-4',"gun-turret-damage-6"}, icon='unlimited-gun-turret-damage'},
    --laser turret damage
    gentable{name='laser-turret-damage', prereqs={'military-4',"laser-turret-damage-6"}, icon='unlimited-laser-turret-damage'},
    --lab speed
    gentable{name='laboratory-speed-modifier', count=600, prereqs={"research-effectivity-4"}, icon='unlimited-lab-efficiency'},
    --maual mining speed
    gentable{name='manual-mining-speed-modifier', count=300, prereqs={"alien-technology"}, icon="unlimited-mining"},
})
--for debug
--data.raw.technology['unl-gun-turret-damage'].prerequisites={}
--data.raw.technology['unl-gun-turret-damage'].unit.count=10
--data.raw.technology['unl-gun-turret-damage'].unit.ingredients={{"science-pack-1", 1}}

