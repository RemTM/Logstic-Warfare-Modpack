require "defines"
require "util"
remote.add_interface("UnlimitedUogrades",
{fix = function()--this function should fix technologies broken by cheating.
    for f in pairs(global.counts) do
            for t in pairs(global.counts[f]) do
                game.forces[f].technologies[t].enabled=true;
                game.forces[f].technologies[t].researched=false;
            end
    end 
end,
})
local predefined={
    ['unl-manual-mining-speed-modifier']={type="mining",count=0},
    ['unl-laboratory-speed-modifier']={type="research",count=0},
    ['unl-gun-turret-damage']={type="gun_turret",count=0},
    ['unl-laser-turret-damage']={type="laser_turret",count=0},
    }
function update_list(force)--initializes counters for technologies in the mod
    global[force.name]=global[force.name] or {}
    local f=global[force.name]
    --search for technologies added by this mod
    for name, tech in pairs(force.technologies) do
        local my = true
        if name:find('^unl%-(.+)%-(.+)$') and not f[name] then--the mighty power of regex
            if predefined[name] then 
                f[name]=predefined[name]
            --then process the ammotypes, which all have the same cource of actions
            elseif name:find('^unl%-(.+)%-damage$') then
                local _,_,ammotype = name:find('^unl%-(.+)%-damage$');
                f[name]={type="damage",count=0,ammotype=ammotype}
            elseif name:find('^unl%-(.+)%-speed$') then
                local _,_,ammotype = name:find('^unl%-(.+)%-speed$');
                f[name]={type="speed",count=0,ammotype=ammotype}
            else  -- this is probably not tech from my mod    
                my=false
            end
        end
    end
end

function progress(count)
--[[returns addition to bonus multiplier]]
--[[currently is something close to log()]]
    local i=1
    repeat i=i+1; until count<3/2*(i^2+3*i);
    return 1/(3*(i+1))
end

function inform(force,techname,addition,multiplier)
--inform players how mighty they now are
    for _,player in pairs(force.players) do
        player.print({"technology-name."..techname})
        player.print("Bonus multiplier-increased-by"..addition)
        player.print("Bonus multiplier-is-now "..multiplier)
    end
end

handlers={--here be functions that do multiplier increase
    mining=function(g,t)
        local add=progress(g.count)
        t.force.manual_mining_speed_modifier=t.force.manual_mining_speed_modifier+add
        inform(t.force,t.name,add,t.force.manual_mining_speed_modifier)
    end,
    research=function(g,t)
        local add=progress(g.count)
        t.force.laboratory_speed_modifier=t.force.laboratory_speed_modifier+add
        inform(t.force,t.name,add,t.force.laboratory_speed_modifier)
    end,
    gun_turret=function(g,t)
        local add=progress(g.count)
        local prev=t.force.get_turret_attack_modifier('gun-turret')
        t.force.set_turret_attack_modifier('gun-turret',prev+add)
        inform(t.force,t.name,add,prev+add)
    end,
    laser_turret=function(g,t)
        local add=progress(g.count)
        local prev=t.force.get_turret_attack_modifier('laser-turret')
        t.force.set_turret_attack_modifier('laser-turret',prev+add)
        inform(t.force,t.name,add,prev+add)
    end,
    damage=function(g,t)
        local add=progress(g.count)
        local prev=t.force.get_ammo_damage_modifier(g.ammotype)
        t.force.set_ammo_damage_modifier(g.ammotype,prev+add)
        inform(t.force,t.name,add,prev+add)
    end,
    speed=function(g,t)
        local add=progress(g.count)
        local prev=t.force.get_gun_speed_modifier(g.ammotype)
        t.force.set_gun_speed_modifier(g.ammotype,prev+add)
        inform(t.force,t.name,add,prev+add)
    end,
}

function forget()--resets the tech for repeated research
    for k,t in pairs(global.just_finished) do
        t.researched=false;
        t.enabled=true;
        global.just_finished[k]=nil
    end
    script.on_event(defines.events.on_tick,nil)
end

script.on_event(defines.events.on_research_finished,function(e)
    local t=e.research
    if not global[t.force.name] then update_list(t.force) end
    if global[t.force.name][t.name] then
        local g=global[t.force.name][t.name]
        handlers[g.type](g,t)
        g.count=g.count+1;
        global.just_finished=global.just_finished or {}
        table.insert(global.just_finished,t)
        script.on_event(defines.events.on_tick, forget)
    end
end)


script.on_configuration_changed(
function()
    for _,f in pairs(game.forces) do
        if (#(f.players)~=nil) then
            update_list(f)
        end
    end
end)
