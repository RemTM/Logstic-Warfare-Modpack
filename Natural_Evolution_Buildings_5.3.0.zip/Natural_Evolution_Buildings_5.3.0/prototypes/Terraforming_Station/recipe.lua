data:extend({
    --- Terraforming Station
	{
        type = "recipe",
        name = "TerraformingStation",
        energy_required = 35,
        enabled = "false",
        ingredients =
        {
            {"Building_Materials", 15},
            {"alien-artifact", 20},
        },
        result = "TerraformingStation"
    },
	
})