data:extend({
{
    type = "recipe",
    name = "alien-artifact-from-small",
    result= "alien-artifact",
    ingredients= { {"small-alien-artifact", 100} },
	energy_required= 5,
    enabled= "true",
	category= "crafting"
  },
})