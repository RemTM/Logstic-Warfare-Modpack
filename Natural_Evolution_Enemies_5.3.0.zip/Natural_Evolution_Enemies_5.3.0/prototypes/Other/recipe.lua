

data:extend({
	{
		type = "recipe",
		name = "Biological-bullet-magazine",
		enabled = false,
		energy_required = 5,
		ingredients =
		{ 
			{"alien-artifact", 2},
			{"plastic-bar", 5},
			{"piercing-bullet-magazine", 5},
		},
		result = "Biological-bullet-magazine",
		result_count = 5
	},

	
})
