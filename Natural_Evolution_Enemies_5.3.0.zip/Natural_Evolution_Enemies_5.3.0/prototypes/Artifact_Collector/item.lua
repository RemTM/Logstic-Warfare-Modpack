data:extend(
	{
		{
			type = "item",
			name = "Artifact-collector-area",
			icon = "__Natural_Evolution_Enemies__/graphics/icons/Artifact-chest-icon.png",
			flags = {"goes-to-quickbar"},
			subgroup = "Tools",
			order = "d[Artifact-collector]",
			place_result = "Artifact-collector-area",
			stack_size = 50
		}
	}
)