data:extend(
	{
		{
			type = "recipe",
			name = "Artifact-collector",
			enabled = "false",
			ingredients =
			{
				{"smart-chest", 4},
				{"stone-brick", 20},
				{"battery", 5}
			},
			result = "Artifact-collector-area"
		}
	}
)
